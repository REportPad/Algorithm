﻿#include <cstring>
#include<map>
#include<algorithm>
#include<math.h>
#include<set>
#include<time.h>
#include"euler.h"

int main() {
	bool flg = true;
	ull sum = 0;
	ull a, b;
	set<ull> s;

	for (a = 1; a < 100000; ++a) {
		for (b = 1; b < 100000; ++b) {
			ull x = a * b;
			string sa = to_string(a);
			string sb = to_string(b);
			string sx = to_string(x);
			string ss = sa + sb + sx;

			//cout << a << ", " << b << ", " << x << ", " << ss << endl;

			if (ss.size() > 9) {
				break;
			}
			else if (ss.size() != 9) {
				flg = false;
			}
			else {
				sort(ss.begin(), ss.end());
				for (int i = 0; i < 9; ++i) {
					char t = (i + 1) + '0';
					if (ss[i] != t) {
						flg = false;
						break;
					}
				}
			}


			if (flg) {
				cout << a << ", " << b << ", " << x << endl;
				s.insert(x);
			}
			flg = true;
		}
	}

	set<ull>::iterator it;

	for (it = s.begin(); it != s.end(); ++it) {
		sum += (*it);
	}

	cout << sum << endl;

	return 0;
}