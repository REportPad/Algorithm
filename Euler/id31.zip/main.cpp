﻿#include <cstring>
#include<map>
#include<algorithm>
#include<math.h>
#include<set>
#include<time.h>
#include"euler.h"

int main(){
	int p[] = {200, 100,50,20,10,5,2, 1 };
	int cnt = 0;
	const int psize = sizeof(p)/sizeof(int);

	int a[8] = {0,};
	for (a[0] = 0; a[0] <= 1; ++a[0]) {//200
		for (a[1] = 0; a[1] <= 2; ++a[1]) {//100
			for (a[2] = 0; a[2] <= 4; ++a[2]) {//50
				for (a[3] = 0; a[3] <= 10; ++a[3]) {//20
					for (a[4] = 0; a[4] <= 20; ++a[4]) {//10
						for (a[5] = 0; a[5] <= 40; ++a[5]) {//5
							for (a[6] = 0; a[6] <= 100; ++a[6]) {//2
								for (a[7] = 0; a[7] <= 200; ++a[7]) {
									int x = 0;
									for (int i = 0; i < psize; ++i) {
										x += a[i] * p[i];
									}

									if (x > 200) {
										break;
									}
									else if (x == 200) {
										++cnt;
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	cout << cnt << endl;
	return 0;
}

