﻿#include <cstring>
#include<map>
#include<algorithm>
#include<math.h>
#include<set>
#include<time.h>
#include"euler.h"


int main(){
	set<string> sets;
	for (int b = 2; b <= 100; ++b) {
		//cout << b << endl;
		for (int a = 2; a <= 100; ++a) {
			string t = BigNumberPower(a, b);
			sets.insert(t);
		}
	}

	cout << sets.size() << endl;

	return 0;
}

