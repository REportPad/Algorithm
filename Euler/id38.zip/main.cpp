﻿#include <cstring>
#include<map>
#include<algorithm>
#include<math.h>
#include<set>
#include<time.h>
#include"euler.h"

int main() {
	int n = 2;
	int i = 1;
	string s = "";
	bool flg = true;
	int best = -1;
	int besti = 0;
	int m = 1;

	while (n < 9400) {
		m = n*i;
		s += to_string(m);

		if (s.size() == 9) {
			string ss = s;
			sort(s.begin(), s.end());
			for (int j = 1; j <= 9; ++j) {
				if (s[j - 1] != (j + '0')) {
					flg = false;
					break;
				}
			}

			if (flg) {
				//cout << "ss: " << ss << endl;
				int a = stoi(ss);
				if (a > best) {
					best = a;
					cout << "best: " << best << endl;
				}
			}
			flg = true;
			++n;
			i = 1;
			s = "";
		}
		else if (s.size() > 9) {
			++n;
			i = 1;
			s = "";
		}
		else {
			++i;
		}
	}

	return 0;
}