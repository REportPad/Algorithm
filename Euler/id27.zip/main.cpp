﻿#include <cstring>
#include<map>
#include<algorithm>
#include<math.h>
#include<set>
#include<time.h>
#include"euler.h"

#define N 1000

int main(){
	int cnt = 0;
	int best = 0;
	int A, B;

	for (int a = -(N-1); a < N; ++a) {
		for (int b = -N; b <= N; ++b) {
			cnt = 0;
			int n = 0;
			while (1) {
				int y = n*n + a*n + b;

				if (isPrime(y)) {
					++cnt;
				}
				else {
					if (cnt > best) {
						best = cnt;
						A = a;
						B = b;
						//cout << A << ", " << B << ", best: " << best << endl;
					}
					break;
				}
				++n;
			}
		}
	}

	cout << A * B << endl;
	return 0;
}

