﻿#include <cstring>
#include<map>
#include<algorithm>
#include<math.h>
#include<set>
#include<time.h>
#include"euler.h"

int main(){
	int d = 1000;
	int best = 6;//1/7
	int cnt = 0;
	int idx = -1;

	for (int i = 11; i < d; ++i) {
		if (isPrime(i)) {
			//cout << i << endl;
			cnt = ReciprocalCycle(i);
			if (cnt > best) {
				best = cnt;
				idx = i;
			}
			best = max(best, cnt);
		}
	}

	cout << idx << endl;

	return 0;
}

