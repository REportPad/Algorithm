#include "euler.h"

bool isTriangleNumber(int x) {
	int n = 1;
	while (1) {
		if (n * (n + 1) == 2 * x) {
			return true;
		}
		else if (n * (n + 1) > 2 * x) {
			return false;
		}
		++n;
	}

	return false;
}


bool isTruncatablePrime(int n) {
	string s = to_string(n);
	int t = n;

	//right to left
	//cout << "right to left" << endl;
	while (s.size() > 0) {
		//cout << "t: " << t << endl;
		if (!isPrime(t)) {
			return false;
		}

		if (s.size() > 1) s.pop_back();
		else break;

		t = stoi(s);
	}

	//left to right
	//cout << "left to right" << endl;
	s = to_string(n);
	int front = 1;

	while (front < s.size()) {
		string st = "";
		for (int i = front; i < s.size(); ++i) {
			st += s[i];
		}
		++front;
		t = stoi(st);
		//cout << "t: " << t << endl;
		if (!isPrime(t)) {
			return false;
		}
	}

	return true;
}


bool isPalindrome(int n, int base) {
	//change base
	int t = n;
	string s = "";
	if (base != 10) {
		while (t > 0) {
			s += (t % base);
			t /= base;
		}

		//reverse(s.begin(), s.end());
	}
	else s = to_string(n);

	for (int i = 0; i < s.size() / 2; ++i) {
		if (s[i] != s[(s.size() - 1) - i]) {
			return false;
		}
	}

	return true;
}

int LeftRotationNumber(int n) {
	string s = to_string(n);
	if (s.size() == 1) return n;

	char c = s[0];

	for (int i = 0; i < s.size() - 1; ++i) {
		s[i] = s[i + 1];
	}
	s[s.size() - 1] = c;

	if (s[0] == '0') return -1;

	int t = stoi(s);
	return t;
}

bool isCircularPrime(int n) {
	int cnt = 0;
	int t = n;
	string s = to_string(n);

	for (int i = 0; i < s.size(); ++i) {
		if (isPrime(t)) {
			++cnt;//101, 011,
		}

		t = LeftRotationNumber(t);
		if (t < 0) {
			return false;
		}
	}

	if (cnt == s.size()) return true;
	else return false;
}


bool isPrime(int x) {
	if (x == 1) return false;
	if (x == 2 || x == 3) return true;

	for (int i = 2; i * i <= x; ++i) {
		if (x % i == 0) {
			return false;
		}
	}

	return true;
}

bool isAmicable(int n) {
	if (n >= 1 && n <= 3) {
		return false;
	}

	int i = 2;
	ull sumA = 1;
	ull sumB = 1;

	while (i * i <= n) {
		if (n % i == 0) {
			sumA += i;
			if ((n / i) != i) {
				sumA += (n / i);
			}
		}
		++i;
	}

	i = 2;
	while (i * i <= sumA) {
		if (sumA % i == 0) {
			sumB += i;
			if ((sumA / i) != i) {
				sumB += (sumA / i);
			}

		}
		++i;
	}

	if (n == sumB && n != sumA) {
		return true;
	}

	return false;
}

int ReadFile(string name, string* number) {
	string line;
	ifstream file(name);

	int i = 0;

	if (file.is_open()) {
		while (getline(file, line)) {
			number[i] = line;
			//cout << number[i] << endl;
			++i;
		}
		//cout << endl;

		file.close();
	}
	else {
		cout << "Unable to open file";
	}

	return i;
}

int DivisorNumber(int x) {
	if (x == 1) return 1;
	if (isPrime(x)) return 2;

	int ret = 2;//1, x
	int n = 2;
	int t = sqrt(x);

	while (t >= n) {
		if (x % n == 0) {
			if (x / n == n) {
				++ret;
				break;
			}
			else {
				ret += 2;
				++n;
			}
		}
		else ++n;
	}

	return ret;
}


ull FactorialDigitCount(int n, int SIZE) {
	ull ret = 0;
	string s = "1";
	string t = "1";
	int x = 0;
	vector<char> c;

	//initialization
	for (int i = 0; i < SIZE; ++i) {
		c.push_back('0');
	}

	for (int i = 2; i <= n; ++i) {
		for (int j = 0; j < i - 1; ++j) {
			x = BigNumberSum(s, t, c, SIZE);
			//cout << "s: " << s << ", t: " << t << endl;
			for (int k = 0; k < SIZE; ++k) {
				if (c[k] != '0') {
					s = c[k];
					for (int u = k + 1; u < SIZE; ++u) {
						s += c[u];
					}
					//cout << "i: " << i << " " << s << endl;
					break;
				}
			}
		}

		cout << "i: " << i << ", " << s << endl;
		t = s;
	}

	for (int i = 0; i < SIZE; ++i) {
		ret += (c[i] - '0');
		//cout  << i << ": " << ret << endl;
	}

	return ret;
}


int BigNumberSum(string a, string b, vector<char>& c, int digit) {//char* c
	if (b.size() > a.size()) {
		string d = a;
		a = b;
		b = d;
	}

	if (a.size() > b.size()) {
		string d = "";
		int m = a.size() - b.size();
		for (int i = 0; i < m; ++i) {
			d += '0';
		}
		d += b;
		b = d;
	}

	//a.size() == b.size()
	int SIZE = min(a.size(), b.size());//12+6=18?
	int carry = 0;
	int cnt = 0;

	for (int i = 0; i < SIZE; ++i) {
		int x = a[(SIZE - 1) - i] - '0';
		int y = b[(SIZE - 1) - i] - '0';
		int z = x + y;
		//cout << "z: " << z << endl;

		if (z + carry < 10) {
			c[(digit - 1) - i] = (z + carry + '0');
			carry = 0;
		}
		else {
			c[(digit - 1) - i] = (z + carry - 10 + '0');
			carry = 1;
		}
		++cnt;
	}

	if (carry) {
		c[(digit - 1) - cnt] = '1';
		++cnt;
	}

	return cnt;
}


string BigNumberSum(string a, string b, int digit) {
	if (b.size() > a.size()) {
		string d = a;
		a = b;
		b = d;
	}

	if (a.size() > b.size()) {
		string d = "";
		int m = a.size() - b.size();
		for (int i = 0; i < m; ++i) {
			d += '0';
		}
		d += b;
		b = d;
	}

	//a.size() == b.size()
	int SIZE = min(a.size(), b.size());
	int carry = 0;
	string c(digit,'0');
	int cnt = 0;
	
	for (int i = 0; i < SIZE; ++i) {
		int x = a[(SIZE - 1) - i] - '0';
		int y = b[(SIZE - 1) - i] - '0';
		int z = x + y;
		//cout << "z: " << z << endl;

		if (z + carry < 10) {
			c[(digit - 1) - i] = (z + carry + '0');
			carry = 0;
		}
		else {
			c[(digit - 1) - i] = (z + carry - 10 + '0');
			carry = 1;
		}
		++cnt;
	}

	if (carry) {
		c[(digit - 1) - cnt] = '1';
		++cnt;
	}

	return c;
}


bool isAbundantNumbers(int n) {
	if (n < 12) return false;

	int t = n;
	int i = 2;
	vi v;
	ull sum = 1;

	while (i * i <= t) {
		if (t % i == 0) {
			v.push_back(i);
			if (i != t / i) {
				v.push_back(t / i);
			}
		}
		++i;
	}

	for (int j = 0; j < v.size(); ++j) {
		sum += v[j];
	}

	if (sum > n) return true;
	return false;
}

string BigNumberPower(int a, int b) {
	if (b == 0 || a == 1) return "1";
	if (b == 1) return to_string(a);
	if (a == 0) return "0";

	string sa = to_string(a);
	int digit = b * log10(a) + 1;
	string t = "";

	for (int j = 0; j < b - 1; ++j) {
		t = "";
		for (int i = 0; i < a; ++i) {
			t = BigNumberSum(t, sa, digit);
			//cout << t << endl;
		}
		sa = t;
	}

	return t;
}

int ReciprocalCycle(int n) {
	if (n % 2 == 0 || n % 5 == 0) return 0;

	int q = 10 / n;
	string s = to_string(q);
	int r = 10 % n;
	int x = r * 10;
	int cnt = 0;
	int starti = 0;
	int startj = 1;
	int length = 1;

	while (1) {
		q = x / n;
		s += to_string(q);
		if (s[starti] == s[startj]) {//00990099...
			if (s[starti] == '0' && (startj - starti == 1)) {
				cnt = 0;
				starti = 0;
				length = s.size();
				++startj;
			}
			else {
				++cnt;
				if ((cnt == length)) break;//0.111..., 0.1212..., 0.123123...,			
				++starti;
				++startj;
			}
		}
		else {
			cnt = 0;
			starti = 0;
			++startj;
			length = s.size();
		}

		r = x % n;
		x = r * 10;
	}

	//cout << "s: " << s << ", cnt: " << cnt << endl;

	return cnt;
}