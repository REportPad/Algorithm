﻿#include <cstring>
#include<map>
#include<algorithm>
#include<math.h>
#include<set>
#include<time.h>
#include"euler.h"

int main(){
	ull x = 0;
	ull y = 0;
	ull sum = 0;

	for (int f = 0; f <= 9; ++f) {
		for (int a = 0; a <= 9; ++a) {
			for (int b = 0; b <= 9; ++b) {
				for (int c = 0; c <= 9; ++c) {
					for (int d = 0; d <= 9; ++d) {
						for (int e = 0; e <= 9; ++e) {
							x = 100000 * f + 10000 * a + 1000 * b + 100 * c + 10 * d + e;
							y = pow(f,5) + pow(a, 5) + pow(b, 5) + pow(c, 5) + pow(d, 5) + pow(e, 5);
							if (x == y) {
								//cout << x << endl;
								sum += x;
							}
						}
					}
				}
			}
		}
	}
	cout << sum -1 << endl;
	return 0;
}

