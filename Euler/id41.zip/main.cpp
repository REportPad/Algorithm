﻿#include <cstring>
#include<map>
#include<algorithm>
#include<math.h>
#include<set>
//#include<time.h>
#include"euler.h"

int main() {
	int n = 3;
	bool flg = true;
	string best = "";
	string s = "";

	while (1) {
		s = to_string(n);

		if (isPrime(n)) {			
			string ss = s;
			sort(s.begin(), s.end());
			for (int i = 0; i < s.size(); ++i) {
				if (s[i] != (i+1+'0')) {
					flg = false;
					break;
				}
			}

			if (flg) {
				best = ss;
				cout << best << endl;
			}
			flg = true;
		}
		n += 2;

		if (s.size() > 9) break;
	}

	return 0;
}