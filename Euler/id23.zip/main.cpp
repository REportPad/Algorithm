﻿#include <cstring>
#include<map>
#include<algorithm>
#include<math.h>
#include<set>
#include"euler.h"

#define N 28123

int main(){
	ull sum = 0;
	vi v;

	for (int i = 12; i <= N; ++i) {
		if (isAbundantNumbers(i)) {
			v.push_back(i);
		}
	}

	set<ull> w;
	for (int i = 0; i < v.size(); ++i) {
		for (int j = i; j < v.size(); ++j) {
			int u = v[i] + v[j];
			if (u <= N) w.insert(u);
			else break;
		}
	}

	set<ull>::iterator iter;
	for (iter = w.begin(); iter != w.end(); iter++) {
		sum += (*iter);
	}

	ull x = N * (N + 1) / 2;

	//cout << "x: " << x << endl;
	//cout <<"sum: " << sum << endl;
	cout << x - sum << endl;

	return 0;
}
