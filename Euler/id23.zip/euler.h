#pragma once
#include<string>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;

typedef unsigned long long ull;
typedef long long ll;
typedef vector<int> vi;


int ReadFile(string name, string* data);
bool isTriangleNumber(int x);
bool isPalindrome(int n, int base);
int DivisorNumber(int x);
bool isAmicable(int n);
bool isPrime(int x);
int LeftRotationNumber(int n);
bool isCircularPrime(int n);
bool isTruncatablePrime(int n);

ull FactorialDigitCount(int n, int SIZE);
int BigNumberSum(string a, string b, vector<char>& c, int digit);//char* c
string BigNumberSum(string a, string b, int digit);
bool isAbundantNumbers(int n);