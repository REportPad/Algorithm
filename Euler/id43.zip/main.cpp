﻿#include <cstring>
#include<map>
#include<algorithm>
#include<math.h>
#include<set>
//#include<time.h>
#include"euler.h"

int main() {
	int p[] = {2,3,5,7,11,13,17};
	int psize = sizeof(p) / sizeof(int);//7
	bool flg = true;
	ull sum = 0;
	string s = "0123456789";
	string::size_type sz = 0;   // alias of size_t

	do {
		if (s[0] != '0') {
			ull u = stoull(s, &sz, 0);

			for (int i = 0; i < psize; ++i) {
				string t = s.substr(1 + i, 3);
				int x = stoi(t);

				if (x % p[i] != 0) {
					flg = false;
					break;
				}
			}

			if (flg) {
				sum += u;
				cout << u << ", " << sum << endl;
			}

			flg = true;
		}
	} while (next_permutation(s.begin(), s.end()) );

	return 0;
}