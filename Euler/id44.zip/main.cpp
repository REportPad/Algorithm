﻿#include <cstring>
#include<map>
#include<algorithm>
#include<math.h>
#include<set>
//#include<time.h>
#include"euler.h"

int main() {
	vector<ull> v;
	ull n = 3;
	ull y = 0;

	v.push_back(1);
	v.push_back(5);

	while (y == 0) {
		ull t = n * (3 * n - 1) / 2;

		for (int i = 0; i < v.size(); ++i) {
			ull sum = t + v[i];
			ull diff = t - v[i];
			double d1 = 1 + sqrt(24 * sum + 1);
			double d2 = 1 + sqrt(24 * diff + 1);

			if (isInteger(d1) && isInteger(d2)) {
				ull ud1 = d1;
				ull ud2 = d2;
				if ((ud1 % 6 == 0) && (ud2 % 6 == 0)) {
					y = t - v[i];
					cout << y << endl;
					break;
				}
			}
		}

		v.push_back(t);
		++n;
	}

	return 0;
}